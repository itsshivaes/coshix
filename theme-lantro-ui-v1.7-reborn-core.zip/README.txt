========================================
        LANTRO UI v1.7 CORE
        Premium Blogger Template
========================================

Thank you for using Lantro UI ❤️
A modern, fast and fully optimized Blogger template.

----------------------------------------
📂 FILES INCLUDED
----------------------------------------

1. lantro-ui-v1.7-core-premium.xml
   → Main Blogger template file

2. docs.html
   → Click to open full documentation

3. Pages Folder
   → Important page codes
      • contact.txt
      • sitemap.txt

4. README.txt
   → Basic instructions

5. lantro-ui-v1.7-core-premium.txt

   → For better theme upload

----------------------------------------
🚀 HOW TO INSTALL TEMPLATE
----------------------------------------

Step 1: Go to Blogger Dashboard  
Step 2: Click Theme  
Step 3: Click drop-down menu
Step 4: Click Restore  
Step 5: Upload "lantro-ui-v1.7-core-premium.xml"  

Template installed successfully.

----------------------------------------
🤦‍♂️ THEME NOT PROPERLY APPLIED
---------------------------------------
Step 1: Go to Blogger Dashboard  
Step 2: Click Theme  
Step 3: Click drop-down menu
Step 4: Click Edit HTML
Step 5: Open "lantro-ui-v1.7-core-premium.txt"
Step 6: Copy all code there then paste it to Blogger HTML
Step 7: Save

Template installed successfully.

----------------------------------------
📄 IMPORTANT PAGE SETUP
----------------------------------------

Contact Page:
Create new page in Blogger → HTML view  
Copy code from: Pages/contact.txt 
Paste and replace YOUREMAIL@example.com with your email.
Publish

Sitemap Page:
Create new page → HTML view  
Copy code from: Pages/sitemap.txt  
Paste and replace https://lantro-ui-core.blogspot.com with your blog url.
Publish

----------------------------------------
📘 DOCUMENTATION
----------------------------------------

Open documentation:
Open "docs.html" file  
OR visit directly:

https://lantro-ui-core.blogspot.com/search/label/Docs

Follow full setup guide there.

----------------------------------------
⚠️ IMPORTANT NOTES
----------------------------------------

• Use official version only  
• Do not resell or redistribute  
• Keep template updated  
• Use documentation for setup  

----------------------------------------
👨‍💻 DEVELOPER
----------------------------------------

Name: Teorzo
Website: https://www.teorzo.xyz 

----------------------------------------
⭐ THANK YOU FOR USING LANTRO UI
----------------------------------------
